import 'package:flutter/material.dart';
import '../services/api_services.dart';
import '../models/meal.dart';
import 'detail_screen.dart';

class HomeScreen extends StatelessWidget {
  final ApiService apiService = ApiService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Meal Categories'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: [
          CategoryCard(category: 'Seafood'),
          CategoryCard(category: 'Dessert'),
          CategoryCard(category: 'Vegan'),
        ],
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  final String category;

  CategoryCard({required this.category});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Meal>>(
      future: ApiService().fetchMeals(category),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        } else if (snapshot.hasData) {
          List<Meal> meals = snapshot.data!;
          return GridView.builder(
            itemCount: meals.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailScreen(meal: meals[index]),
                    ),
                  );
                },
                child: Card(
                  child: Column(
                    children: [
                      Image.network(meals[index].imageUrl),
                      Text(meals[index].name),
                    ],
                  ),
                ),
              );
            },
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
            ),
          );
        } else {
          return Center(child: Text('No data available'));
        }
      },
    );
  }
}
