import 'package:flutter/material.dart';
import '../models/meal.dart';

class DetailScreen extends StatelessWidget {
  final Meal meal;

  DetailScreen({required this.meal});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Hero(
        tag: meal.id,
        child: Material(
          child: Column(
            children: [
              Image.network(meal.imageUrl),
              SizedBox(height: 10),
              Text(meal.name, style: TextStyle(fontSize: 24)),
            ],
          ),
        ),
      ),
    );
  }
}
