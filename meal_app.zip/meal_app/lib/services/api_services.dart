import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/meal.dart';

class ApiService {
  final String baseUrl = "https://www.themealdb.com/api/json/v1/1/filter.php?c=";

  Future<List<Meal>> fetchMeals(String category) async {
    final response = await http.get(Uri.parse(baseUrl + category));

    if (response.statusCode == 200) {
      final data = json.decode(response.body)['meals'];
      return (data as List).map((meal) => Meal.fromJson(meal)).toList();
    } else {
      throw Exception('Failed to load meals');
    }
  }
}
